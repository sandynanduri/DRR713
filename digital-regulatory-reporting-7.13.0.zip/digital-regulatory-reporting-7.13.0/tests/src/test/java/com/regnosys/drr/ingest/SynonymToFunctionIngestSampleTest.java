package com.regnosys.drr.ingest;

import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * A test class to validate that the synonym ingest and function ingest test packs contain the same sample files.
 */
public class SynonymToFunctionIngestSampleTest {

    @ParameterizedTest(name = "{0}")
    @MethodSource("inputPaths")
    void testInputFolder(String name, Path synonymInput, Path functionInput) throws IOException {
        assertNotNull(synonymInput, "Synonym Ingest test pack input sample is missing  " + name);
        assertNotNull(functionInput, "Function Ingest test pack input sample is missing " + name);
        assertEquals(Files.readString(synonymInput), Files.readString(functionInput), "Synonym test pack input sample does not match Function Ingest input sample: " + name);
//        Files.copy(synonymInput, functionInput, StandardCopyOption.REPLACE_EXISTING);
    }

    private static Stream<Arguments> inputPaths() throws IOException {
        Map<String, Path> synonymInputsMap = nameToPathMap("../rosetta-source/src/main/resources/cdm-sample-files");
        Map<String, Path> functionInputsMap = nameToPathMap("../rosetta-source/src/main/resources/ingest/input");

        Set<String> names = new HashSet<>();
        names.addAll(synonymInputsMap.keySet());
        names.addAll(functionInputsMap.keySet());

        List<Arguments> arguments = new ArrayList<>();
        for (String name : names) {
            arguments.add(Arguments.of(name, synonymInputsMap.get(name), functionInputsMap.get(name)));
        }
        return arguments.stream();
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("outputPaths")
    void testOutputFolder(String name, Path synonymOutput, Path functionOutput) {
        assertNotNull(synonymOutput, "Synonym Ingest test pack output sample is missing " + name);
        assertNotNull(functionOutput, "Function Ingest test pack output sample is missing " + name);
    }

    private static Stream<Arguments> outputPaths() throws IOException {
        Map<String, Path> synonymOutputsMap = nameToPathMap("../rosetta-source/src/main/resources/result-json-files");
        Map<String, Path> functionOutputsMap = nameToPathMap("../rosetta-source/src/main/resources/ingest/output/fpml-record-keeping-to-reportable-event");

        List<Arguments> arguments = new ArrayList<>();
        for (String name : synonymOutputsMap.keySet()) {
            arguments.add(Arguments.of(name, synonymOutputsMap.get(name), functionOutputsMap.get(name)));
        }
        return arguments.stream();
    }

    @NotNull
    private static Map<String, Path> nameToPathMap(String path) throws IOException {
        List<Path> paths = Files.walk(Path.of(path))
                .filter(Files::isRegularFile)
                .filter(x -> !x.getFileName().toString().endsWith("expectations.json"))
                .collect(Collectors.toList());
        return paths.stream().collect(Collectors.toMap(SynonymToFunctionIngestSampleTest::removeExt, x -> x));
    }

    @NotNull
    private static String removeExt(Path x) {
        String fileName = x.getFileName().toString();
        return fileName.substring(0, fileName.lastIndexOf('.'));
    }
}
