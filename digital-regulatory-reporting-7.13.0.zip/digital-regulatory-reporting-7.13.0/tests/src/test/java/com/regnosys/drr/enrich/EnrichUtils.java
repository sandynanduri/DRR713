package com.regnosys.drr.enrich;

import com.regnosys.rosetta.common.transform.TransformType;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.stream.Stream;

public class EnrichUtils {

    public static final Path ENRICH_CONFIG_PATH = Paths.get(TransformType.ENRICH.getResourcePath()).resolve("config");
    public static final Path ENRICH_INPUT_PATH = Paths.get(TransformType.ENRICH.getResourcePath()).resolve("input");
    
    public static void copyFoldersAndFiles(Path inputPath, Path outputPath) {
        try (Stream<Path> inputPathStream = Files.walk(inputPath)) {
            inputPathStream.forEach(sourcePath -> {
                try {
                    Path relativePath = inputPath.relativize(sourcePath);
                    Path targetPath = outputPath.resolve(relativePath);

                    if (Files.isDirectory(sourcePath)) {
                        Files.createDirectories(targetPath);
                    } else {
                        Files.createDirectories(targetPath.getParent());
                        Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                    }
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            });
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
