package com.regnosys.drr.ingest;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Sets;
import com.regnosys.ingest.test.framework.ingestor.testing.Expectation;
import com.regnosys.rosetta.common.util.UrlUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class SynonymIngestExpectationTest {

    private static final String CDM_SAMPLE_FILES = "cdm-sample-files/";
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final TypeReference<List<Expectation>> TYPE_REFERENCE = new TypeReference<>() {
    };
    private static final Path RESOURCES_FOLDER = Path.of("../rosetta-source/src/main/resources");

    private static List<Arguments> namedArguments() throws IOException {
        Path sampleFilesDir = RESOURCES_FOLDER.resolve(CDM_SAMPLE_FILES);
        return Files.walk(sampleFilesDir)
                .filter(x -> x.getFileName().toString().equals("expectations.json"))
                .map(path -> Arguments.of(sampleFilesDir.relativize(path.getParent()).toString()
                        .replace(File.pathSeparatorChar, '-'), path))
                .collect(Collectors.toList());
    }

    @ParameterizedTest(name = "{0}")
    @MethodSource("namedArguments")
    void checkExpectationsIsComplete(String name, Path expectationsPath) throws IOException, URISyntaxException {
        Set<String> expectationsSamples = MAPPER.readValue(UrlUtils.toUrl(expectationsPath), TYPE_REFERENCE)
                .stream().map(Expectation::getFileName).collect(Collectors.toSet());

        Set<String> xmlFilesInDir = Files.list(expectationsPath.getParent())
                .filter(x -> x.toString().endsWith(".xml"))
                .map(RESOURCES_FOLDER::relativize).map(UrlUtils::toPortableString)
                .collect(Collectors.toSet());
        Assertions.assertEquals(expectationsSamples, xmlFilesInDir, "Missing xml sample in expectations.json" + Sets.difference(xmlFilesInDir, expectationsSamples));
    }
}