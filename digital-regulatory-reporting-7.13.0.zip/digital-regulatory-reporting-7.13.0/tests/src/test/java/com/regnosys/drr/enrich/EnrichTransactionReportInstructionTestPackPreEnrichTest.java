package com.regnosys.drr.enrich;

import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TestPackModel;
import com.regnosys.testing.transform.TransformTestExtension;
import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackPreEnrich;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.regnosys.drr.enrich.EnrichUtils.ENRICH_CONFIG_PATH;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class EnrichTransactionReportInstructionTestPackPreEnrichTest {

    @RegisterExtension
    static TransformTestExtension<Enrich_TransactionReportInstructionTestPackPreEnrich> testExtension =
            new TransformTestExtension<>(
                    new ReportTestRuntimeModule(),
                    ENRICH_CONFIG_PATH,
                    Enrich_TransactionReportInstructionTestPackPreEnrich.class);

    @ParameterizedTest(name = "{0}")
    @MethodSource("inputFiles")
    void runIngest(String testName,
                   String testPackId,
                   TestPackModel.SampleModel sampleModel) {
        testExtension.runTransformAndAssert(testPackId, sampleModel);
    }

    private static Stream<Arguments> inputFiles() {
        return testExtension.getArguments();
    }
}

