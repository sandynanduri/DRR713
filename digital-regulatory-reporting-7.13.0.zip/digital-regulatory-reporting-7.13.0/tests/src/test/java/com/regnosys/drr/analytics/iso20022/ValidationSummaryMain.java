package com.regnosys.drr.analytics.iso20022;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.regnosys.drr.analytics.TransformData;
import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TestPackUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

import static com.regnosys.drr.analytics.iso20022.Iso20022ValidationSummaryCreator.*;
import static com.regnosys.rosetta.common.transform.TestPackUtils.PROJECTION_PATH;


public class ValidationSummaryMain {

    private static final Logger LOGGER = LoggerFactory.getLogger(ValidationSummaryMain.class);

    private static final Path ANALYTICS_PATH = PROJECTION_PATH.resolve("analytics");

    private static final List<TransformData> PROJECTIONS =
            List.of(ASIC_TRADE, ASIC_MARGIN, ASIC_VALUATION,
                    CFTC_PART43_TRADE, CFTC_PART45_TRADE, CFTC_VALUATION,
                    CSA_TRADE, CSA_PPD_TRADE, CSA_VALUATION,
                    EMIR_TRADE, EMIR_MARGIN, EMIR_VALUATION,
                    FCA_UKEMIR_TRADE, FCA_UKEMIR_MARGIN, FCA_UKEMIR_VALUATION,
                    HKMA_DTCC_TRADE, HKMA_DTCC_MARGIN, HKMA_DTCC_VALUATION,
                    HKMA_TR_TRADE, HKMA_TR_MARGIN, HKMA_TR_VALUATION,
                    JFSA_TRADE, JFSA_MARGIN, JFSA_VALUATION,
                    MAS_TRADE, MAS_MARGIN, MAS_VALUATION);

    public static void main(String[] args) {
        try {
            ValidationSummaryMain validationSummaryMain = new ValidationSummaryMain();
            validationSummaryMain.run();
            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Error executing {}.main()", ValidationSummaryMain.class.getName(), e);
            System.exit(1);
        }
    }

    public void run() throws IOException {
        Injector injector = Guice.createInjector(new ReportTestRuntimeModule());
        Iso20022ValidationSummaryCreator creator = injector.getInstance(Iso20022ValidationSummaryCreator.class);
        creator.generateValidationSummaryAndWriteCsv(PROJECTIONS, TestPackUtils.PROJECTION_CONFIG_PATH, ANALYTICS_PATH);
    }
}
