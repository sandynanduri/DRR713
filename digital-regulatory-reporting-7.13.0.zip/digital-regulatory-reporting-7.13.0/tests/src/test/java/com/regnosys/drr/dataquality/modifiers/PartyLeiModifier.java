package com.regnosys.drr.dataquality.modifiers;

import com.regnosys.drr.dataquality.util.XmlDom;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Node;

import javax.xml.xpath.XPathExpressionException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;

import static com.regnosys.drr.dataquality.modifiers.TestPackModifierHelper.*;

@SuppressWarnings("unused") // instantiated reflectively
public class PartyLeiModifier extends BaseModifier {

    private static final Pattern VALID_LEI_PATTERN = Pattern.compile("[A-Z0-9]{18,18}[0-9]{2,2}");
    private static final Logger LOGGER = LoggerFactory.getLogger(PartyLeiModifier.class);

    public PartyLeiModifier(ModifierContext context) {
        super(context);
    }

    @Override
    public boolean isApplicable(Path xmlFile, String xmlContent, XmlDom xml) throws XPathExpressionException {
        List<Node> partyNodes = xml.getList(PARTY_XPATH);
        if (partyNodes.isEmpty()) {
            LOGGER.warn("Sample {} has no parties", xmlFile.getFileName());
            return false;
        }
        List<String> partyReferenceHrefs = getCounterpartyHrefs(xml);
        if (partyReferenceHrefs.size() != 2) {
            LOGGER.warn("Sample {} does not have 2 counterparties, but has {}", xmlFile.getFileName(), partyReferenceHrefs.size());
            return false;
        }
        return !xmlFile.getFileName().toString().contains("mockup-data-masking");
    }

    @Override
    public void modify(Path xmlFile, XmlDom xml) throws XPathExpressionException {
        List<String> partyReferenceHrefs = getCounterpartyHrefs(xml);
        List<Node> partyNodes = xml.getList(PARTY_XPATH);
        modifyLei(xml, partyNodes, partyReferenceHrefs.get(0), PARTY1_LEI);
        modifyLei(xml, partyNodes, partyReferenceHrefs.get(1), PARTY2_LEI);
    }

    private void modifyLei(XmlDom xml, List<Node> partyNodes, String id, String validLei) throws XPathExpressionException {
        Node partyNode = getPartyNode(partyNodes, id);
        Node leiPartyNode = xml.getList(partyNode, "partyId").stream()
                .filter(p -> attributeEquals(p, "partyIdScheme", LEI_SCHEME))
                .findFirst()
                .orElse(null);
        if (leiPartyNode != null) {
            String existingLei = leiPartyNode.getTextContent();
            if (!isValidLei(existingLei)) {
                LOGGER.info("Replacing invalid LEI {} with {}", existingLei, validLei);
                leiPartyNode.setTextContent(validLei);
                replaceAll(xml, existingLei, validLei);
            }
        } else {
            LOGGER.info("Adding missing partyId LEI {}", validLei);
            Node newPartyIdNode = xml.createNode("partyId", Map.of("partyIdScheme", LEI_SCHEME), validLei);
            xml.addFirst(partyNode, newPartyIdNode);
        }
    }

    private static void replaceAll(XmlDom xml, String find, String replace) throws XPathExpressionException {
        List<Node> nodes = xml.getList("//*[text()='" + find + "']");
        nodes.forEach(node -> {
            String nodeName = node.getNodeName();
            LOGGER.info("Found {} at node {}, replacing with {}", find, nodeName, replace);
            if (nodeName.equals("sentBy")) {
                Optional.ofNullable(node.getAttributes().getNamedItem("messageAddressScheme")).ifPresent(a -> a.setTextContent(LEI_SCHEME));
            }
            node.setTextContent(replace);
        });
    }

    private boolean isValidLei(String lei) {
        boolean patternValid = VALID_LEI_PATTERN.matcher(lei).matches();
        String lei18 = lei.substring(0, 18);
        String checksum = lei.substring(18, 20);
        String computedLeiChecksum = computeLeiChecksum(lei18);
        boolean checksumValid = computedLeiChecksum.equals(checksum);
        boolean result = patternValid && checksumValid;
        if (!result) {
            LOGGER.info("Invalid LEI {}, pattern is {}, checksum: {}, computed checksum: {}", lei, patternValid ? "valid" : "invalid", checksum, computedLeiChecksum);
        }
        return result;
    }

    static String computeLeiChecksum(String lei18) {
        if (lei18 == null) {
            return null;
        }
        // Convert each character to its numeric representation.
        // The result is built as a string of decimal digits.
        StringBuilder numeric = new StringBuilder(36); // each letter becomes two digits
        for (char c : lei18.toCharArray()) {
            if (c >= '0' && c <= '9') {
                numeric.append(c);
            } else {
                numeric.append(Character.getNumericValue(c));
            }
        }
        // Append the two zeros required by the algorithm.
        numeric.append("00");
        // Compute (numericString mod 97) using a streaming remainder
        // to avoid overflow of the intermediate value.
        int remainder = 0;
        for (int i = 0; i < numeric.length(); i++) {
            char digitChar = numeric.charAt(i);
            int digit = digitChar - '0';
            remainder = (remainder * 10 + digit) % 97;
        }
        int check = 98 - remainder;
        return (check < 10 ? "0" : "") + check;
    }
}
