package com.regnosys.drr.ingest.diagnostics;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.regnosys.rosetta.common.serialisation.RosettaObjectMapper;
import com.regnosys.rosetta.common.transform.TransformType;

import java.nio.file.Path;

import static com.regnosys.rosetta.common.RegPaths.directoryNameOfDataset;
import static com.regnosys.testing.TestingExpectationUtil.TEST_WRITE_BASE_PATH;

public class IngestUtils {

    public static final String FUNCTION_FOLDER = "fpml-record-keeping-to-reportable-event";
    static final ObjectMapper OBJECT_MAPPER = RosettaObjectMapper.getNewMinimalRosettaObjectMapper();

    static final Path PROJECT_ROOT = Path.of("").toAbsolutePath().getParent();
    public static final Path MAIN_RESOURCES_PATH = TEST_WRITE_BASE_PATH.orElseThrow();
    static final Path INGEST_OUTPUT_PATH = MAIN_RESOURCES_PATH.resolve(TransformType.TRANSLATE.getResourcePath()).resolve("output");
    public static final Path SYNONYM_INGEST_OUTPUT_BASE_PATH = MAIN_RESOURCES_PATH.resolve("result-json-files");

    static boolean isJsonExt(Path synonymIngestOutputPath) {
        return synonymIngestOutputPath.getFileName().toString().endsWith(".json");
    }

    static String toTestPackName(String synonymIngestOutputPath) {
        String testPackName = synonymIngestOutputPath.replaceAll("[-._/]+", " ");
        return directoryNameOfDataset(testPackName);
    }

    static Path getIngestOutputPath(String testPackName, Path fileName) {
        return INGEST_OUTPUT_PATH.resolve(FUNCTION_FOLDER).resolve(testPackName).resolve(fileName);
    }
}
