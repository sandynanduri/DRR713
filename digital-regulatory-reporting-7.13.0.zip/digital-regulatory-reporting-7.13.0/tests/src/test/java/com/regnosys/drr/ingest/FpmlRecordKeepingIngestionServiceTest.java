package com.regnosys.drr.ingest;

import com.google.common.collect.ImmutableList;
import com.regnosys.drr.DrrRuntimeModuleExternalApi;
import com.regnosys.ingest.test.framework.ingestor.ExpectationUtil;
import com.regnosys.ingest.test.framework.ingestor.IngestionTest;
import com.regnosys.ingest.test.framework.ingestor.IngestionTestUtil;
import com.regnosys.ingest.test.framework.ingestor.service.IngestionFactory;
import com.regnosys.ingest.test.framework.ingestor.service.IngestionService;
import com.regnosys.ingest.test.framework.ingestor.testing.Expectation;
import drr.regulation.common.ReportableEvent;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.provider.Arguments;

import java.net.URL;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

public class FpmlRecordKeepingIngestionServiceTest extends IngestionTest<ReportableEvent> {

    private static final ImmutableList<String> SAMPLE_FILES_DIR = ImmutableList.of(
            "cdm-sample-files/cftc-event-scenarios/expectations.json",
            "cdm-sample-files/commodity/expectations.json",
            "cdm-sample-files/credit/expectations.json",
            "cdm-sample-files/custom-scenarios/expectations.json",
            "cdm-sample-files/delegated-reporting/expectations.json",
            "cdm-sample-files/equity/expectations.json",
            "cdm-sample-files/etd/expectations.json",
            "cdm-sample-files/events/expectations.json",
            "cdm-sample-files/exotic/expectations.json",
            "cdm-sample-files/fx/expectations.json",
            "cdm-sample-files/pre-enrich/expectations.json",
            "cdm-sample-files/rates/expectations.json");
    private static IngestionService ingestionService;

    @BeforeAll
    static void setup() {
        ClassLoader classLoader = FpmlRecordKeepingIngestionServiceTest.class.getClassLoader();
        URL ingestionConfig = Objects.requireNonNull(classLoader.getResource("ingestions/drr-ingestions.json"));
        DrrRuntimeModuleExternalApi runtimeModule = new DrrRuntimeModuleExternalApi();
        initialiseIngestionFactory(List.of(ingestionConfig), runtimeModule, IngestionTestUtil.getPostProcessors(runtimeModule));
        ingestionService = IngestionFactory.getInstance().getService("FpML_5_RecordKeeping_To_ReportableEvent");
    }

    @Override
    protected Class<ReportableEvent> getClazz() {
        return ReportableEvent.class;
    }

    @Override
    protected IngestionService ingestionService() {
        return ingestionService;
    }

    @SuppressWarnings("unused")//used by the junit parameterized test
    private static Stream<Arguments> fpMLFiles() {
        return readExpectationsFromString(SAMPLE_FILES_DIR);
    }

    public void updateExpectations() {
        // Ensure environment is set up
        setup();
        fpMLFiles().forEach(e -> {
            Object[] argsArray = e.get();
            String expectationFilePath = (String) argsArray[0];
            Expectation expectation = (Expectation) argsArray[1];
            try {
                writeIngestionExpectation(expectationFilePath, expectation);
            } catch (Throwable ex) {
                throw new RuntimeException(ex);
            }
        });
    }
}