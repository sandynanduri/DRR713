package com.regnosys.drr.testpack;

import com.google.common.base.Stopwatch;
import com.google.common.collect.ImmutableMap;
import com.google.inject.Injector;
import com.regnosys.drr.analytics.iso20022.ValidationSummaryMain;
import com.regnosys.drr.enrich.CFTCEventScenariosExampleSubmissionWorkflowTest;
import com.regnosys.drr.ingest.FpmlRecordKeepingIngestionServiceTest;
import com.regnosys.drr.ingest.diagnostics.IngestBasicDiagnosticsCreator;
import com.regnosys.drr.ingest.diagnostics.IngestExpectationDiffCreator;
import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TransformType;
import com.regnosys.runefpml.RuneFpmlModelConfig;
import com.regnosys.testing.TestingExpectationUtil;
import com.regnosys.testing.pipeline.PipelineConfigWriter;
import com.regnosys.testing.pipeline.PipelineFilter;
import com.regnosys.testing.pipeline.PipelineTreeConfig;
import com.rosetta.model.lib.functions.RosettaFunction;
import com.rosetta.model.lib.reports.ReportFunction;
import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackDefault;
import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackPreEnrich;
import drr.ingest.fpml.recordkeeping.message.functions.Ingest_FpmlRecordKeepingToReportableEvent;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.trade.functions.Project_CftcPart43TradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.trade.functions.Project_CftcPart45TradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.valuation.functions.Project_CFTCValuationReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.trade.functions.Project_CSATradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.trade.functions.Project_CsaPpdReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.valuation.functions.Project_CSAValuationReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.sec.rewrite.trade.functions.Project_SECTradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.sec.rewrite.trade.functions.Project_SecPpdReportToDtccRdsHarmonized;
import drr.projection.iso20022.asic.rewrite.margin.functions.Project_ASICMarginReportToIso20022;
import drr.projection.iso20022.asic.rewrite.trade.functions.Project_ASICTradeReportToIso20022;
import drr.projection.iso20022.asic.rewrite.valuation.functions.Project_ASICValuationReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.margin.functions.Project_EsmaEmirMarginReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.trade.functions.Project_EsmaEmirTradeReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.valuation.functions.Project_EsmaEmirValuationReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.margin.functions.Project_FcaUkEmirMarginReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.trade.functions.Project_FcaUkEmirTradeReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.valuation.functions.Project_FcaUkEmirValuationReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.margin.dtcc.functions.Project_HKMADtccMarginReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.margin.tr.functions.Project_HKMATrMarginReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.trade.dtcc.functions.Project_HKMADtccTradeReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.trade.tr.functions.Project_HKMATrTradeReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.valuation.dtcc.functions.Project_HKMADtccValuationReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.valuation.tr.functions.Project_HKMATrValuationReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.margin.functions.Project_JFSARewriteMarginReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.trade.functions.Project_JFSARewriteTradeReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.valuation.functions.Project_JFSARewriteValuationReportToIso20022;
import drr.projection.iso20022.mas.rewrite.margin.functions.Project_MASMarginReportToIso20022;
import drr.projection.iso20022.mas.rewrite.trade.functions.Project_MASTradeReportToIso20022;
import drr.projection.iso20022.mas.rewrite.valuation.functions.Project_MASValuationReportToIso20022;
import drr.regulation.asic.rewrite.margin.reports.ASICMarginReportFunction;
import drr.regulation.asic.rewrite.trade.reports.ASICTradeReportFunction;
import drr.regulation.asic.rewrite.valuation.reports.ASICValuationReportFunction;
import drr.regulation.cftc.rewrite.margin.reports.CFTCMarginReportFunction;
import drr.regulation.cftc.rewrite.trade.reports.CFTCPart43ReportFunction;
import drr.regulation.cftc.rewrite.trade.reports.CFTCPart45ReportFunction;
import drr.regulation.cftc.rewrite.valuation.reports.CFTCValuationReportFunction;
import drr.regulation.csa.rewrite.margin.reports.CSAMarginReportFunction;
import drr.regulation.csa.rewrite.trade.reports.CSAPPDReportFunction;
import drr.regulation.csa.rewrite.trade.reports.CSATradeReportFunction;
import drr.regulation.csa.rewrite.valuation.reports.CSAValuationReportFunction;
import drr.regulation.esma.emir.refit.margin.reports.ESMAEMIRMarginReportFunction;
import drr.regulation.esma.emir.refit.trade.reports.ESMAEMIRTradeReportFunction;
import drr.regulation.esma.emir.refit.valuation.reports.ESMAEMIRValuationReportFunction;
import drr.regulation.fca.ukemir.refit.margin.reports.FCAUKEMIRMarginReportFunction;
import drr.regulation.fca.ukemir.refit.trade.reports.FCAUKEMIRTradeReportFunction;
import drr.regulation.fca.ukemir.refit.valuation.reports.FCAUKEMIRValuationReportFunction;
import drr.regulation.hkma.rewrite.margin.reports.HKMAMarginReportFunction;
import drr.regulation.hkma.rewrite.trade.reports.HKMATradeReportFunction;
import drr.regulation.hkma.rewrite.valuation.reports.HKMAValuationReportFunction;
import drr.regulation.jfsa.rewrite.margin.reports.JFSAMarginReportFunction;
import drr.regulation.jfsa.rewrite.trade.reports.JFSATradeReportFunction;
import drr.regulation.jfsa.rewrite.valuation.reports.JFSAValuationReportFunction;
import drr.regulation.mas.rewrite.margin.reports.MASMarginReportFunction;
import drr.regulation.mas.rewrite.trade.reports.MASTradeReportFunction;
import drr.regulation.mas.rewrite.valuation.reports.MASValuationReportFunction;
import drr.regulation.sec.rewrite.trade.reports.SECPPDReportFunction;
import drr.regulation.sec.rewrite.trade.reports.SECTradeReportFunction;
import fpml.consolidated.doc.Document;
import iso20022.Iso20022ModelConfig;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Path;
import java.util.Map;
import java.util.function.Predicate;

import static com.regnosys.testing.pipeline.PipelineFilter.startsWith;
import static iso20022.Iso20022ModelConfig.TYPE_TO_SCHEMA_MAP;
import static iso20022.Iso20022ModelConfig.TYPE_TO_XML_CONFIG_MAP;
import static org.apache.commons.io.FileUtils.deleteDirectory;

public class DrrTestPackCreator {

    private static final Logger LOGGER = LoggerFactory.getLogger(DrrTestPackCreator.class);

    private static final Predicate<String> TRADE_COMMON_TEST_PACKS = startsWith("credit", "custom-scenarios", "equity", "events", "fx");
    private static final Predicate<String> PRE_ENRICH_TEST_PACK = PipelineFilter.equalsTo("pre-enrich");

    @Inject
    private PipelineConfigWriter pipelineConfigWriter;

    @Inject
    private FpmlRecordKeepingIngestionServiceTest fpmlRecordKeepingIngestionServiceTest;

    @Inject
    private CFTCEventScenariosExampleSubmissionWorkflowTest cftcEventScenariosExampleSubmissionWorkflowTest;

    @Inject
    private ValidationSummaryMain validationSummaryMain;

    public static void main(String[] args) {
        try {
            DrrTestPackCreator testPackConfigCreator = new DrrTestPackCreator();

            setupInjector(testPackConfigCreator);

            Stopwatch t = Stopwatch.createStarted();
            //run clean to delete test packs to be regenerated NOT run for ING
            testPackConfigCreator.clean();

            testPackConfigCreator.runSynonymIngestion();
            testPackConfigCreator.runFunctionIngest();
            testPackConfigCreator.runCFTCEventScenariosExampleSubmissionWorkflowTest();

            testPackConfigCreator.generatePipelines();

            testPackConfigCreator.runValidationSummary();

            LOGGER.info("DRR pipeline / test pack update took {}", t);

            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Error executing {}.main()", DrrTestPackCreator.class.getName(), e);
            System.exit(1);
        }
    }

    private static void setupInjector(DrrTestPackCreator drrTestPackCreator) {
        Injector injector = new ReportTestRuntimeModule.InjectorProvider().getInjector();
        injector.injectMembers(drrTestPackCreator);
    }

    private void clean() throws IOException {
        Path path = TestingExpectationUtil.TEST_WRITE_BASE_PATH.get();
        // These will all get regenerated by the PipelineConfigWriter
        deleteDirectory(path.resolve("result-json-file").toFile());
        deleteDirectory(path.resolve("mapping-analytics").toFile());
        deleteDirectory(path.resolve("ingest/config").toFile());
        deleteDirectory(path.resolve("ingest/output").toFile());
        deleteDirectory(path.resolve("enrich").toFile());
        deleteDirectory(path.resolve("regulatory-reporting/config").toFile());
        deleteDirectory(path.resolve("regulatory-reporting/output").toFile());
        deleteDirectory(path.resolve("projection").toFile());
    }

    private void runSynonymIngestion() {
        LOGGER.info(" ** Updating expectations for fpmlRecordKeepingIngestionServiceTest");
        fpmlRecordKeepingIngestionServiceTest.updateExpectations();
    }

    private void runCFTCEventScenariosExampleSubmissionWorkflowTest() throws Exception {
        LOGGER.info(" ** Updating expectations for cftcEventScenariosExampleSubmissionWorkflowTest");
        cftcEventScenariosExampleSubmissionWorkflowTest.updateExpectations();
    }

    private void runValidationSummary() throws Exception {
        LOGGER.info("** Updating expectations for validationSummaryTest");
        validationSummaryMain.run();
    }

    private void generatePipelines() throws IOException {
        writeAsicTradeConfig();
        writeCftcPart43Config();
        writeCftcPart45Config();
        writeCsaPpdConfig();
        writeCsaTradeConfig();
        writeEsmaTradeConfig();
        writeFcaConfig();
        writeHkmaDtccTradeConfig();
        writeHkmaTrTradeConfig();
        writeJfsaConfig();
        writeMasTradeConfig();
        writeSecTradeConfig();
        writeSecPpdConfig();

        pipelineConfigWriter.writePipelinesAndTestPacks(createASICValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createCSAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createCFTCValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createESMAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createFCAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createHKMAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createJFSAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createMASValuationTreeConfig(startsWith("valuation")));

        pipelineConfigWriter.writePipelinesAndTestPacks(createCollateralTreeConfig(startsWith("collateral")));
    }

    private void runFunctionIngest() throws IOException {
        pipelineConfigWriter.writePipelinesAndTestPacks(getFunctionIngestConfig());
        new IngestBasicDiagnosticsCreator().generateIngestBasicDiagnostics();
        new IngestExpectationDiffCreator().generateIngestExpectationDiffs();
    }

    private PipelineTreeConfig getFunctionIngestConfig() {
        PipelineTreeConfig pipelineConfig = new PipelineTreeConfig()
                .starting(TransformType.TRANSLATE, Ingest_FpmlRecordKeepingToReportableEvent.class);
        return addXMLAndSchemaMap(pipelineConfig);
    }

    // Trade

    private PipelineTreeConfig getTradeConfig(Predicate<String> testPackFilter,
                                              Class<? extends RosettaFunction> enrichFunc,
                                              Class<? extends ReportFunction<?, ?>> reportFunc,
                                              Class<? extends RosettaFunction> projectionFunc) {
        final PipelineTreeConfig pipelineConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackFilter)
                .starting(TransformType.TRANSLATE, Ingest_FpmlRecordKeepingToReportableEvent.class)
                .add(Ingest_FpmlRecordKeepingToReportableEvent.class, TransformType.ENRICH, enrichFunc)
                .add(enrichFunc, TransformType.REPORT, reportFunc)
                .add(reportFunc, TransformType.PROJECTION, projectionFunc);
        return addXMLAndSchemaMap(pipelineConfig);
    }

    private void writeTradeConfig(Predicate<String> testPackFilter, Class<? extends ReportFunction<?, ?>> reportFunc, Class<? extends RosettaFunction> projectionFunc) {
        try {
            pipelineConfigWriter.writePipelinesAndTestPacks(
                    getTradeConfig(testPackFilter,
                            Enrich_TransactionReportInstructionTestPackDefault.class,
                            reportFunc,
                            projectionFunc));
            pipelineConfigWriter.writePipelinesAndTestPacks(
                    getTradeConfig(PRE_ENRICH_TEST_PACK,
                            Enrich_TransactionReportInstructionTestPackPreEnrich.class,
                            reportFunc,
                            projectionFunc));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private void writeAsicTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), ASICTradeReportFunction.class, Project_ASICTradeReportToIso20022.class);
    }

    private void writeCftcPart43Config() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("cftc-event-scenarios", "rates")), CFTCPart43ReportFunction.class, Project_CftcPart43TradeReportToDtccRdsHarmonized.class);
    }

    private void writeCftcPart45Config() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("cftc-event-scenarios", "rates")), CFTCPart45ReportFunction.class, Project_CftcPart45TradeReportToDtccRdsHarmonized.class);
    }

    private void writeCsaPpdConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "cftc-event-scenarios", "rates")), CSAPPDReportFunction.class, Project_CsaPpdReportToDtccRdsHarmonized.class);
    }

    private void writeCsaTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "cftc-event-scenarios", "rates")), CSATradeReportFunction.class, Project_CSATradeReportToDtccRdsHarmonized.class);
    }

    private void writeEsmaTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("delegated-reporting", "etd", "commodity", "rates")), ESMAEMIRTradeReportFunction.class, Project_EsmaEmirTradeReportToIso20022.class);
    }

    private void writeFcaConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("rates")), FCAUKEMIRTradeReportFunction.class, Project_FcaUkEmirTradeReportToIso20022.class);
    }

    private void writeHkmaDtccTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), HKMATradeReportFunction.class, Project_HKMADtccTradeReportToIso20022.class);
    }

    private void writeHkmaTrTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), HKMATradeReportFunction.class, Project_HKMATrTradeReportToIso20022.class);
    }

    private void writeJfsaConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), JFSATradeReportFunction.class, Project_JFSARewriteTradeReportToIso20022.class);
    }

    private void writeMasTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), MASTradeReportFunction.class, Project_MASTradeReportToIso20022.class);
    }

    private void writeSecTradeConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), SECTradeReportFunction.class, Project_SECTradeReportToDtccRdsHarmonized.class);
    }

    private void writeSecPpdConfig() {
        writeTradeConfig(TRADE_COMMON_TEST_PACKS.or(startsWith("commodity", "rates")), SECPPDReportFunction.class, Project_SecPpdReportToDtccRdsHarmonized.class);
    }

    // Valuation

    private PipelineTreeConfig createASICValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig asicValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, ASICValuationReportFunction.class)
                .add(ASICValuationReportFunction.class, TransformType.PROJECTION, Project_ASICValuationReportToIso20022.class);

        return addXMLAndSchemaMap(asicValuationConfig);
    }

    public PipelineTreeConfig createCSAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig csaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CSAValuationReportFunction.class)
                .add(CSAValuationReportFunction.class, TransformType.PROJECTION, Project_CSAValuationReportToDtccRdsHarmonized.class);

        return addXMLAndSchemaMap(csaValuationConfig);
    }

    private PipelineTreeConfig createCFTCValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig cftcValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CFTCValuationReportFunction.class)
                .add(CFTCValuationReportFunction.class, TransformType.PROJECTION, Project_CFTCValuationReportToDtccRdsHarmonized.class);

        return addXMLAndSchemaMap(cftcValuationConfig);
    }

    private PipelineTreeConfig createESMAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig esmaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)
                .starting(TransformType.REPORT, ESMAEMIRValuationReportFunction.class)
                .add(ESMAEMIRValuationReportFunction.class, TransformType.PROJECTION, Project_EsmaEmirValuationReportToIso20022.class);
        return addXMLAndSchemaMap(esmaValuationConfig);
    }

    private PipelineTreeConfig createFCAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig fcaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)
                .starting(TransformType.REPORT, FCAUKEMIRValuationReportFunction.class)
                .add(FCAUKEMIRValuationReportFunction.class, TransformType.PROJECTION, Project_FcaUkEmirValuationReportToIso20022.class);
        return addXMLAndSchemaMap(fcaValuationConfig);
    }

    public PipelineTreeConfig createHKMAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig hkmaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, HKMAValuationReportFunction.class)
                .add(HKMAValuationReportFunction.class, TransformType.PROJECTION, Project_HKMATrValuationReportToIso20022.class)
                .add(HKMAValuationReportFunction.class, TransformType.PROJECTION, Project_HKMADtccValuationReportToIso20022.class);

        return addXMLAndSchemaMap(hkmaValuationConfig);
    }

    private PipelineTreeConfig createJFSAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig jfsaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, JFSAValuationReportFunction.class)
                .add(JFSAValuationReportFunction.class, TransformType.PROJECTION, Project_JFSARewriteValuationReportToIso20022.class);

        return addXMLAndSchemaMap(jfsaValuationConfig);
    }

    public PipelineTreeConfig createMASValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig masValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, MASValuationReportFunction.class)
                .add(MASValuationReportFunction.class, TransformType.PROJECTION, Project_MASValuationReportToIso20022.class);

        return addXMLAndSchemaMap(masValuationConfig);
    }

    // Collateral

    private PipelineTreeConfig createCollateralTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig collateralTreeConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CFTCMarginReportFunction.class)

                .starting(TransformType.REPORT, ASICMarginReportFunction.class)
                .add(ASICMarginReportFunction.class, TransformType.PROJECTION, Project_ASICMarginReportToIso20022.class)

                .starting(TransformType.REPORT, CSAMarginReportFunction.class)

                .starting(TransformType.REPORT, HKMAMarginReportFunction.class)

                .starting(TransformType.REPORT, ESMAEMIRMarginReportFunction.class)
                .add(ESMAEMIRMarginReportFunction.class, TransformType.PROJECTION, Project_EsmaEmirMarginReportToIso20022.class)

                .starting(TransformType.REPORT, FCAUKEMIRMarginReportFunction.class)
                .add(FCAUKEMIRMarginReportFunction.class, TransformType.PROJECTION, Project_FcaUkEmirMarginReportToIso20022.class)

                .starting(TransformType.REPORT, JFSAMarginReportFunction.class)
                .add(JFSAMarginReportFunction.class, TransformType.PROJECTION, Project_JFSARewriteMarginReportToIso20022.class)

                .starting(TransformType.REPORT, MASMarginReportFunction.class)
                .add(MASMarginReportFunction.class, TransformType.PROJECTION, Project_MASMarginReportToIso20022.class)

                .starting(TransformType.REPORT, HKMAMarginReportFunction.class)
                .add(HKMAMarginReportFunction.class, TransformType.PROJECTION, Project_HKMADtccMarginReportToIso20022.class)
                .add(HKMAMarginReportFunction.class, TransformType.PROJECTION, Project_HKMATrMarginReportToIso20022.class);

        return addXMLAndSchemaMap(collateralTreeConfig);
    }

    private PipelineTreeConfig addXMLAndSchemaMap(PipelineTreeConfig pipelineTreeConfig) {
        ImmutableMap<Class<?>, String> fpmlTypeToXmlConfigMap = ImmutableMap.<Class<?>, String>builder()
                .put(Document.class, RuneFpmlModelConfig.FPML_RECORDKEEPING_XML_CONFIG_PATH)
                .build();

        ImmutableMap<Class<?>, String> fpmlTypeToSchemaMap = ImmutableMap.<Class<?>, String>builder()
                .put(Document.class, RuneFpmlModelConfig.FPML_RECORDKEEPING_SCHEMA_PATH)
                .build();

        return pipelineTreeConfig
                .withXmlConfigMap(mergeMaps(fpmlTypeToXmlConfigMap, TYPE_TO_XML_CONFIG_MAP))
                .withXmlSchemaMap(mergeMaps(fpmlTypeToSchemaMap, TYPE_TO_SCHEMA_MAP))
                .withInputSerialisationFormatMap(RuneFpmlModelConfig.TYPE_TO_FORMAT_MAP)
                .withOutputSerialisationFormatMap(Iso20022ModelConfig.TYPE_TO_FORMAT_MAP)
                .strictUniqueIds();
    }

    private static <T> ImmutableMap<Class<?>, T> mergeMaps(Map<Class<?>, ? extends T> map1, Map<Class<?>, ? extends T> map2) {
        return ImmutableMap.<Class<?>, T>builder()
                .putAll(map1)
                .putAll(map2)
                .build();
    }
}
