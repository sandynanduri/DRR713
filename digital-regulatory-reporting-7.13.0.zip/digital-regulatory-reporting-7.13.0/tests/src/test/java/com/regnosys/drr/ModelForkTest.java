package com.regnosys.drr;

import com.github.difflib.DiffUtils;
import com.github.difflib.patch.Patch;
import com.github.difflib.unifieddiff.UnifiedDiff;
import com.github.difflib.unifieddiff.UnifiedDiffFile;
import com.github.difflib.unifieddiff.UnifiedDiffWriter;
import com.regnosys.rosetta.common.util.Pair;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * This test will fail if BNPP forks any file from DRR or CDM.
 */
public class ModelForkTest {

    private static final Logger LOGGER = LoggerFactory.getLogger(ModelForkTest.class);
    static final Boolean UPDATE_OR_CREATE_MODEL_DIFFS = Optional.ofNullable(System.getenv("UPDATE_OR_CREATE_MODEL_DIFFS")).map(Boolean::parseBoolean).orElse(false);

    public static void main(String[] args) {
        try {
            ModelForkTest modelForkTest = new ModelForkTest();
            modelForkTest.run();
            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Error executing {}.main()", ModelForkTest.class.getName(), e);
            System.exit(1);
        }
    }
    @Test
    void assertNoForkedFiles() throws IOException {
        // when some forked files get added, then this test can be deleted and the ParameterizedTest enabled
        assertTrue(inputs().findAny().isEmpty());
    }

    public void run() throws IOException {

        inputs().forEach(e -> {
            Object[] argsArray = e.get();
            String modelFileName = (String) argsArray[0];
            Path parentModelFile = (Path) argsArray[1];
            Path modelFile = (Path) argsArray[2];
            Path expectedDiffFile = (Path) argsArray[3];
            String expectedDiff = (String) argsArray[4];
            try {
                checkIfFileIsForked(modelFileName, parentModelFile, modelFile, expectedDiffFile, expectedDiff);
            } catch (Throwable ex) {
                throw new RuntimeException(ex);
            }

        });
    }
    public static Stream<Arguments> inputs() throws IOException {
        Path diffFilesPath = Path.of("src/main/resources");
        
        Map<String, Pair<Path, String>> expectedDiffs = Files.exists(diffFilesPath) ? Files.list(diffFilesPath)
                .filter(x -> x.getFileName().toString().endsWith(".diff"))
                .collect(Collectors.toMap(ModelForkTest::rosettaFileNameFromDiff, p -> Pair.of(p, readDiffFile(p)))) : Collections.emptyMap();


        List<Arguments> arguments = new ArrayList<>();

        List<Path> modelFiles = Files.walk(Path.of("../rosetta-source/src/main/rosetta"))
                .filter(x -> x.getFileName().toString().endsWith(".rosetta"))
                .collect(Collectors.toList());

        Set<String> modelFileNames = modelFiles.stream().map(x -> x.getFileName().toString()).collect(Collectors.toSet());

        List<Path> parentModelFiles = Files.walk(Path.of("../rosetta-source/target/parent-dependency"))
                .filter(x -> x.getFileName().toString().endsWith(".rosetta"))
                .filter(x -> modelFileNames.contains(x.getFileName().toString()))
                .collect(Collectors.toList());

        System.out.println();

        for (Path parentModelFile : parentModelFiles) {
            String parentModelFileName = parentModelFile.getFileName().toString();

            Path modelFile = modelFiles.stream()
                    .filter(x -> x.getFileName().toString().equals(parentModelFileName))
                    .findFirst().orElseThrow();

            String modelFileName = modelFile.getFileName().toString();
            Pair<Path, String> expectedDiff = expectedDiffs.get(modelFileName);

            arguments.add(Arguments.of(modelFileName, parentModelFile, modelFile,
                    Optional.ofNullable(expectedDiff).map(Pair::left).orElse(null),
                    Optional.ofNullable(expectedDiff).map(Pair::right).orElse(null)));
        }

        return arguments.stream();
    }

    @MethodSource("inputs")
    @ParameterizedTest(autoCloseArguments = true, name = "{0}")
    @Disabled
    void checkIfFileIsForked(String modelFileName, Path parentModelFile, Path modelFile, Path expectedDiffFile, String expectedDiff) throws IOException {
        List<String> parentModelFileContent = Files.readAllLines(parentModelFile);
        parentModelFileContent.remove(1); // remove version line (e.g version "6.0.0-dev.101")
        List<String> modelFileContent = Files.readAllLines(modelFile);
        modelFileContent.remove(1); // remove version line (e.g.version "${project.version}"
        String namespaceLineWithOverride = modelFileContent.get(0);
        assertTrue(namespaceLineWithOverride.startsWith("override "));
        modelFileContent.remove(namespaceLineWithOverride);
        modelFileContent.add(0, namespaceLineWithOverride.replace("override ", ""));

        if (parentModelFileContent.equals(modelFileContent)) {
//            Files.delete(modelFile);
//            Files.delete(expectedDiffFile);
            assertNull(expectedDiff, "Stale diff file  " + modelFileName + ". You probably want to delete it");
            assertEquals(Files.readString(parentModelFile), Files.readString(modelFile), "File " + modelFileName + " was forked but there is no change in the file. It is likely that this is forked accidentally by Rosetta");
        } else {
            String parentModelFileName = parentModelFile.getFileName().toString();
            String actualDiff = createPatchFile(parentModelFileContent, modelFileContent, parentModelFileName, modelFileName);
            if (expectedDiff != null) {
                printFilePaths(parentModelFile, modelFile, expectedDiffFile);
                if (UPDATE_OR_CREATE_MODEL_DIFFS) {
                    updateOrCreateForkedModelDiffs(modelFileName, actualDiff);
                } else {
                    assertEquals(expectedDiff, actualDiff);
                }
            } else {
                if (UPDATE_OR_CREATE_MODEL_DIFFS) {
                    updateOrCreateForkedModelDiffs(modelFileName, actualDiff);
                } else {
                    assertEquals(Files.readString(parentModelFile), Files.readString(modelFile), "File " + modelFileName + " was unexpected forked ." + actualDiff);
                }
            }
        }
    }

    private static void updateOrCreateForkedModelDiffs(String modelFileName, String actualDiff) throws IOException {
        if (UPDATE_OR_CREATE_MODEL_DIFFS) {
            Path path = Path.of(String.format("src/main/resources/expected-%s.diff", modelFileName.replace(".rosetta", "")));
            Files.createDirectories(path.getParent());
            Files.write(path, actualDiff.getBytes());
        }
    }

    private static void printFilePaths(Path parentModelFile, Path modelFile, Path expectedDiffFile) {
        // Print the file names so its easier to nav
        Path parentModelPath = parentModelFile.toAbsolutePath().normalize();
        Path forkedPath = modelFile.toAbsolutePath().normalize();
        Path expectedDiffPath = expectedDiffFile.toAbsolutePath().normalize();

        System.out.println("parentModelFile  : (file://" + parentModelPath + ")");
        System.out.println("modelFile        : (file://" + forkedPath + ")");
        System.out.println("expectedDiffFile : (file://" + expectedDiffPath + ")");

        System.out.printf("idea diff %s %s %s%n", parentModelPath, forkedPath, parentModelPath.toString().replace("parent-dependency", "parent-dependency-base"));
        System.out.println();
    }

    @NotNull
    private static String createPatchFile(List<String> parentModelFileContent, List<String> modelFileContent, String parentModelFileName, String modelFileName) throws IOException {
        Patch<String> patch = DiffUtils.diff(parentModelFileContent, modelFileContent);
        UnifiedDiffFile revised = UnifiedDiffFile.from(parentModelFileName, modelFileName, patch);
        UnifiedDiff unifiedDiff = UnifiedDiff.from(null, null, revised);
        StringBuilder writer = new StringBuilder();
        UnifiedDiffWriter.write(unifiedDiff, f -> parentModelFileContent, s -> writer.append(s.trim()).append("\n"), 0);
        return writer.toString();
    }


    private static String rosettaFileNameFromDiff(Path file) {
        List<String> diffLines;
        try {
            diffLines = Files.readAllLines(file);
        } catch (IOException e) {
            LOGGER.error("Failed to read file " + file.getFileName().toString(), e);
            throw new RuntimeException(e);
        }

        String firstDiffLine = diffLines.get(0);
        if (!firstDiffLine.startsWith("---")) {
            throw new IllegalStateException("Expected --- as the first line of the diff " + file.getFileName().toString());
        }
        if (!firstDiffLine.endsWith(".rosetta")) {
            throw new IllegalStateException("Expected diff file to be a .rosetta file" + file.getFileName().toString());
        }

        return firstDiffLine.replace("---", "").trim();
    }


    private static String readDiffFile(Path file) {
        try {
            return Files.readString(file);
        } catch (IOException e) {
            LOGGER.error("Failed to read file " + file.getFileName().toString(), e);
            throw new RuntimeException(e);
        }
    }
}
