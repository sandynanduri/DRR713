# Product Diagnostics

| FpML Product | Samples | Completeness |
|:-----------------------------------------------|:-------:|:-------:|
| genericProduct | 6 | 116% |
| regulatoryProductInfo | 1 | 109% |
| creditDefaultSwap | 21 | 109% |
| fxSingleLeg | 18 | 108% |
| fxOption | 11 | 108% |
| creditDefaultSwapOption | 5 | 107% |
| varianceSwap | 2 | 106% |
| bondOption | 8 | 106% |
| fxDigitalOption | 3 | 105% |
| equityOption | 9 | 105% |
| volatilitySwapTransactionSupplement | 1 | 105% |
| fxSwap | 1 | 105% |
| commoditySwap | 22 | 104% |
| capFloor | 3 | 104% |
| fra | 2 | 103% |
| swap | 62 | 103% |
| returnSwap | 12 | 103% |
| equitySwapTransactionSupplement | 4 | 103% |
| commodityOption | 8 | 102% |
| commoditySwaption | 1 | 100% |
| swaption | 5 | 100% |
| dividendSwapTransactionSupplement | 2 | 96% |
