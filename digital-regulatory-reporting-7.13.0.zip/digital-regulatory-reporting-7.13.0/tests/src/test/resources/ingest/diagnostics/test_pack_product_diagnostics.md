# Test Pack / Product Diagnostics

| Test Pack | FpML Product | Samples | Completeness |
|:-----------------------------------------------------|:-----------------------------------------------|:-------:|:-------:|
| cftc-event-scenarios | creditDefaultSwap | 2 | 112% |
| cftc-event-scenarios | swap | 11 | 102% |
| cftc-event-scenarios | swaption | 2 | 99% |
| commodity | commodityOption | 6 | 102% |
| commodity | commoditySwap | 15 | 103% |
| commodity | commoditySwaption | 1 | 100% |
| credit | creditDefaultSwap | 9 | 110% |
| credit | creditDefaultSwapOption | 5 | 107% |
| custom-scenarios | commodityOption | 2 | 103% |
| custom-scenarios | commoditySwap | 4 | 107% |
| custom-scenarios | creditDefaultSwap | 3 | 105% |
| custom-scenarios | equitySwapTransactionSupplement | 2 | 103% |
| custom-scenarios | fxSingleLeg | 2 | 104% |
| custom-scenarios | fxSwap | 1 | 105% |
| custom-scenarios | regulatoryProductInfo | 1 | 109% |
| custom-scenarios | swap | 7 | 102% |
| custom-scenarios | swaption | 1 | 96% |
| custom-scenarios | varianceSwap | 1 | 108% |
| custom-scenarios | volatilitySwapTransactionSupplement | 1 | 105% |
| delegated-reporting | bondOption | 7 | 106% |
| equity | dividendSwapTransactionSupplement | 2 | 96% |
| equity | equityOption | 9 | 105% |
| equity | returnSwap | 12 | 103% |
| equity | varianceSwap | 1 | 104% |
| events | commoditySwap | 3 | 110% |
| events | creditDefaultSwap | 5 | 110% |
| events | fxSingleLeg | 1 | 109% |
| events | swap | 8 | 102% |
| exotic | creditDefaultSwap | 2 | 104% |
| exotic | fxDigitalOption | 3 | 105% |
| exotic | fxOption | 1 | 108% |
| exotic | genericProduct | 4 | 121% |
| fx | fxOption | 10 | 107% |
| fx | fxSingleLeg | 15 | 108% |
| pre-enrich | equitySwapTransactionSupplement | 2 | 103% |
| rates | bondOption | 1 | 105% |
| rates | capFloor | 3 | 104% |
| rates | fra | 2 | 103% |
| rates | genericProduct | 2 | 106% |
| rates | swap | 36 | 104% |
| rates | swaption | 2 | 104% |
