package drr.standards.iso.functions;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ComputeLeiChecksumImplTest {

    private ComputeLeiChecksumImpl computeLeiChecksum;

    @BeforeEach
    public void setUp() {
        computeLeiChecksum = new ComputeLeiChecksumImpl();
    }

    @Test
    public void testDoEvaluate_WithKnownLei() {
        // Using a known LEI example: "R0MUWSFPU8MPRO8K5P83"
        // The first 18 characters are: "R0MUWSFPU8MPRO8K5P"
        // The last 2 characters (checksum) are: "83"
        String lei18 = "R0MUWSFPU8MPRO8K5P";
        String expectedChecksum = "83";

        String result = computeLeiChecksum.doEvaluate(lei18);

        assertEquals(expectedChecksum, result, "Checksum should match the expected value");
    }

    @Test
    public void testDoEvaluate_WithNumericCharacters() {
        // Test with a string containing only numeric characters
        String lei18 = "123456789012345678";
        String result = computeLeiChecksum.doEvaluate(lei18);

        // The checksum should be 2 digits
        assertEquals(2, result.length(), "Checksum should be 2 digits");
        // Verify the checksum is numeric
        assertTrue(result.matches("\\d{2}"), "Checksum should be numeric");
    }

    @Test
    public void testDoEvaluate_WithAlphabeticCharacters() {
        // Test with a string containing only alphabetic characters
        String lei18 = "ABCDEFGHIJKLMNOPQR";
        String result = computeLeiChecksum.doEvaluate(lei18);

        // The checksum should be 2 digits
        assertEquals(2, result.length(), "Checksum should be 2 digits");
        // Verify the checksum is numeric
        assertTrue(result.matches("\\d{2}"), "Checksum should be numeric");
    }

    @Test
    public void testDoEvaluate_WithMixedCharacters() {
        // Test with a string containing mixed alphanumeric characters
        String lei18 = "A1B2C3D4E5F6G7H8I9";
        String result = computeLeiChecksum.doEvaluate(lei18);

        // The checksum should be 2 digits
        assertEquals(2, result.length(), "Checksum should be 2 digits");
        // Verify the checksum is numeric
        assertTrue(result.matches("\\d{2}"), "Checksum should be numeric");
    }

    @Test
    public void testDoEvaluate_WithRealWorldExamples() {
        // Test with some real-world LEI prefixes
        // These are made-up examples based on the LEI format
        String[] leiPrefixes = {
                "5493000IBP32UQZ0KL24",  // Deutsche Bank AG (first 18 chars)
                "549300TRUWO2CD2G5692",  // Barclays Bank PLC (first 18 chars)
                "HWUPKR0MPOU8FGXBT39",   // Made-up example
                "XKZZ2JZF41MRHTR1V493", // Made-up example
                "WITHDRAWALERRORE0122", // Made-up example
                "WITHDRAWALERRORE0316", // Made-up example
                "WITHDRAWALTERMIN0204" // Made-up example
        };

        for (String leiPrefix : leiPrefixes) {
            String lei18 = leiPrefix.substring(0, 18);
            String result = computeLeiChecksum.doEvaluate(lei18);
            
            // The checksum should be 2 digits
            assertEquals(2, result.length(), "Checksum should be 2 digits for " + lei18);
            // Verify the checksum is numeric
            assertTrue(result.matches("\\d{2}"), "Checksum should be numeric for " + lei18);
        }
    }

    @Test
    public void testDoEvaluate_WithEdgeCases() {
        // Test with edge cases

        // All zeros
        String allZeros = "000000000000000000";
        String result1 = computeLeiChecksum.doEvaluate(allZeros);
        assertEquals(2, result1.length(), "Checksum should be 2 digits");
        assertTrue(result1.matches("\\d{2}"), "Checksum should be numeric");

        // All nines
        String allNines = "999999999999999999";
        String result2 = computeLeiChecksum.doEvaluate(allNines);
        assertEquals(2, result2.length(), "Checksum should be 2 digits");
        assertTrue(result2.matches("\\d{2}"), "Checksum should be numeric");

        // Alternating zeros and nines
        String alternating = "090909090909090909";
        String result3 = computeLeiChecksum.doEvaluate(alternating);
        assertEquals(2, result3.length(), "Checksum should be 2 digits");
        assertTrue(result3.matches("\\d{2}"), "Checksum should be numeric");
    }
}