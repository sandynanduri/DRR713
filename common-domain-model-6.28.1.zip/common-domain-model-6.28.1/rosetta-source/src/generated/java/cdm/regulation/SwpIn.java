package cdm.regulation;

import cdm.regulation.meta.SwpInMeta;
import com.rosetta.model.lib.RosettaModelObject;
import com.rosetta.model.lib.RosettaModelObjectBuilder;
import com.rosetta.model.lib.annotations.Accessor;
import com.rosetta.model.lib.annotations.AccessorType;
import com.rosetta.model.lib.annotations.Required;
import com.rosetta.model.lib.annotations.RosettaAttribute;
import com.rosetta.model.lib.annotations.RosettaDataType;
import com.rosetta.model.lib.annotations.RuneAttribute;
import com.rosetta.model.lib.annotations.RuneDataType;
import com.rosetta.model.lib.meta.RosettaMetaData;
import com.rosetta.model.lib.path.RosettaPath;
import com.rosetta.model.lib.process.BuilderMerger;
import com.rosetta.model.lib.process.BuilderProcessor;
import com.rosetta.model.lib.process.Processor;
import java.util.Objects;

import static java.util.Optional.ofNullable;

/**
 * @version 0.0.0.master-SNAPSHOT
 */
@RosettaDataType(value="SwpIn", builder=SwpIn.SwpInBuilderImpl.class, version="0.0.0.master-SNAPSHOT")
@RuneDataType(value="SwpIn", model="cdm", builder=SwpIn.SwpInBuilderImpl.class, version="0.0.0.master-SNAPSHOT")
public interface SwpIn extends RosettaModelObject {

	SwpInMeta metaData = new SwpInMeta();

	/*********************** Getter Methods  ***********************/
	Sngl getSngl();

	/*********************** Build Methods  ***********************/
	SwpIn build();
	
	SwpIn.SwpInBuilder toBuilder();
	
	static SwpIn.SwpInBuilder builder() {
		return new SwpIn.SwpInBuilderImpl();
	}

	/*********************** Utility Methods  ***********************/
	@Override
	default RosettaMetaData<? extends SwpIn> metaData() {
		return metaData;
	}
	
	@Override
	@RuneAttribute("@type")
	default Class<? extends SwpIn> getType() {
		return SwpIn.class;
	}
	
	@Override
	default void process(RosettaPath path, Processor processor) {
		processRosetta(path.newSubPath("sngl"), processor, Sngl.class, getSngl());
	}
	

	/*********************** Builder Interface  ***********************/
	interface SwpInBuilder extends SwpIn, RosettaModelObjectBuilder {
		Sngl.SnglBuilder getOrCreateSngl();
		@Override
		Sngl.SnglBuilder getSngl();
		SwpIn.SwpInBuilder setSngl(Sngl sngl);

		@Override
		default void process(RosettaPath path, BuilderProcessor processor) {
			processRosetta(path.newSubPath("sngl"), processor, Sngl.SnglBuilder.class, getSngl());
		}
		

		SwpIn.SwpInBuilder prune();
	}

	/*********************** Immutable Implementation of SwpIn  ***********************/
	class SwpInImpl implements SwpIn {
		private final Sngl sngl;
		
		protected SwpInImpl(SwpIn.SwpInBuilder builder) {
			this.sngl = ofNullable(builder.getSngl()).map(f->f.build()).orElse(null);
		}
		
		@Override
		@RosettaAttribute("sngl")
		@Accessor(AccessorType.GETTER)
		@Required
		@RuneAttribute("sngl")
		public Sngl getSngl() {
			return sngl;
		}
		
		@Override
		public SwpIn build() {
			return this;
		}
		
		@Override
		public SwpIn.SwpInBuilder toBuilder() {
			SwpIn.SwpInBuilder builder = builder();
			setBuilderFields(builder);
			return builder;
		}
		
		protected void setBuilderFields(SwpIn.SwpInBuilder builder) {
			ofNullable(getSngl()).ifPresent(builder::setSngl);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || !(o instanceof RosettaModelObject) || !getType().equals(((RosettaModelObject)o).getType())) return false;
		
			SwpIn _that = getType().cast(o);
		
			if (!Objects.equals(sngl, _that.getSngl())) return false;
			return true;
		}
		
		@Override
		public int hashCode() {
			int _result = 0;
			_result = 31 * _result + (sngl != null ? sngl.hashCode() : 0);
			return _result;
		}
		
		@Override
		public String toString() {
			return "SwpIn {" +
				"sngl=" + this.sngl +
			'}';
		}
	}

	/*********************** Builder Implementation of SwpIn  ***********************/
	class SwpInBuilderImpl implements SwpIn.SwpInBuilder {
	
		protected Sngl.SnglBuilder sngl;
		
		@Override
		@RosettaAttribute("sngl")
		@Accessor(AccessorType.GETTER)
		@Required
		@RuneAttribute("sngl")
		public Sngl.SnglBuilder getSngl() {
			return sngl;
		}
		
		@Override
		public Sngl.SnglBuilder getOrCreateSngl() {
			Sngl.SnglBuilder result;
			if (sngl!=null) {
				result = sngl;
			}
			else {
				result = sngl = Sngl.builder();
			}
			
			return result;
		}
		
		@RosettaAttribute("sngl")
		@Accessor(AccessorType.SETTER)
		@Required
		@RuneAttribute("sngl")
		@Override
		public SwpIn.SwpInBuilder setSngl(Sngl _sngl) {
			this.sngl = _sngl == null ? null : _sngl.toBuilder();
			return this;
		}
		
		@Override
		public SwpIn build() {
			return new SwpIn.SwpInImpl(this);
		}
		
		@Override
		public SwpIn.SwpInBuilder toBuilder() {
			return this;
		}
	
		@SuppressWarnings("unchecked")
		@Override
		public SwpIn.SwpInBuilder prune() {
			if (sngl!=null && !sngl.prune().hasData()) sngl = null;
			return this;
		}
		
		@Override
		public boolean hasData() {
			if (getSngl()!=null && getSngl().hasData()) return true;
			return false;
		}
	
		@SuppressWarnings("unchecked")
		@Override
		public SwpIn.SwpInBuilder merge(RosettaModelObjectBuilder other, BuilderMerger merger) {
			SwpIn.SwpInBuilder o = (SwpIn.SwpInBuilder) other;
			
			merger.mergeRosetta(getSngl(), o.getSngl(), this::setSngl);
			
			return this;
		}
	
		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || !(o instanceof RosettaModelObject) || !getType().equals(((RosettaModelObject)o).getType())) return false;
		
			SwpIn _that = getType().cast(o);
		
			if (!Objects.equals(sngl, _that.getSngl())) return false;
			return true;
		}
		
		@Override
		public int hashCode() {
			int _result = 0;
			_result = 31 * _result + (sngl != null ? sngl.hashCode() : 0);
			return _result;
		}
		
		@Override
		public String toString() {
			return "SwpInBuilder {" +
				"sngl=" + this.sngl +
			'}';
		}
	}
}
